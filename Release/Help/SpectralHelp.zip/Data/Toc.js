CMCXmlParser._FilePathToXmlStringMap.Add(
	'Toc',
	'<?xml version=\"1.0\" encoding=\"utf-8\"?>' +
	'<CatapultToc Version=\"1\" DescendantCount=\"59\">' +
	'    <TocEntry Title=\"Welcome\" Link=\"/Content/Welcome.htm\" ComputedResetPageLayout=\"true\" ComputedFirstTopic=\"true\" DescendantCount=\"0\" />' +
	'    <TocEntry Title=\"Spectral Toolbar\" Link=\"/Content/Toolbars/Spectral_Toolbar.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'    <TocEntry Title=\"Importers\" Link=\"/Content/Importers/aster_spectral_signature_importer.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"9\">' +
	'        <TocEntry Title=\"ASTER Spectral Signature Importer\" Link=\"/Content/Importers/aster_spectral_signature_importer.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"DG Importer\" Link=\"/Content/Importers/DG_Importer.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Digital Globe Importer Options\" Link=\"/Content/Importers/Digital_Globe_Importer_Options.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Landsat GeoTIFF Importer\" Link=\"/Content/Importers/Landsat_GeoTIFF_Importer.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Landsat GeoTIFF Importer Options\" Link=\"/Content/Importers/Landsat_GeoTIFF_Importer_Options.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Landsat ETM+ Importer\" Link=\"/Content/Importers/landsat_etm+_importer.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Landsat TM Importer\" Link=\"/Content/Importers/landsat_tm_importer.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Signature Importer\" Link=\"/Content/Importers/signature_importer.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Spectral Signature Library Importer\" Link=\"/Content/Importers/spectral_signature_library_importer.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'    </TocEntry>' +
	'    <TocEntry Title=\"Preprocessing\" Link=\"/Content/Preprocessing/empirical_line_method_(elm)_calibration.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"2\">' +
	'        <TocEntry Title=\"Empirical Line Method (ELM) Calibration\" Link=\"/Content/Preprocessing/empirical_line_method_(elm)_calibration.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"IARR\" Link=\"/Content/Preprocessing/IARR.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'    </TocEntry>' +
	'    <TocEntry Title=\"Exploitation Tools\" Link=\"/Content/Exploitation_Tools/spectral_library_builder.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"16\">' +
	'        <TocEntry Title=\"Spectral Library Builder\" Link=\"/Content/Exploitation_Tools/spectral_library_builder.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"9\">' +
	'            <TocEntry Title=\"Spectral Library Builder\" Link=\"/Content/Exploitation_Tools/spectral_library_builder.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"Create a New Spectral Library\" Link=\"/Content/Exploitation_Tools/Create_a_New_Spectral_Library.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"Load a Spectral Library\" Link=\"/Content/Exploitation_Tools/Load_a_Spectral_Library.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"Add Signatures to a Spectral Library\" Link=\"/Content/Exploitation_Tools/Add_Signatures_to_a_Spectral_Library.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"Delete a Signature from a Library\" Link=\"/Content/Exploitation_Tools/Delete_a_Signature_from_a_Library.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"Delete a Spectral Library\" Link=\"/Content/Exploitation_Tools/Delete_a_Spectral_Library.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"Save a Signature\" Link=\"/Content/Exploitation_Tools/Save_a_Signature.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"Save a Spectral Library\" Link=\"/Content/Exploitation_Tools/Save_a_Spectral_Library.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"Spectral Library Builder Algorithm Information\" Link=\"/Content/Exploitation_Tools/Spectral_Library_Builder_Algorithm_Information.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        </TocEntry>' +
	'        <TocEntry Title=\"Range Profiles\" Link=\"/Content/Exploitation_Tools/Range_Profiles.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Working With Plot Profiles\" Link=\"/Content/Exploitation_Tools/Working_With_Plot_Profiles.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Minimum Noise Fraction Transform\" Link=\"/Content/Exploitation_Tools/MNF_Transform.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"3\">' +
	'            <TocEntry Title=\"Minimum Noise Fraction Transform\" Link=\"/Content/Exploitation_Tools/MNF_Transform.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"MNF Forward Transform\" Link=\"/Content/Exploitation_Tools/MNF_Forward.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"MNF Inverse Transform\" Link=\"/Content/Exploitation_Tools/MNF_Inverse.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        </TocEntry>' +
	'    </TocEntry>' +
	'    <TocEntry Title=\"Material Identification\" Link=\"/Content/Material_ID/Material_ID_Plug-Ins.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"11\">' +
	'        <TocEntry Title=\"ACE\" Link=\"/Content/Material_ID/About_the_Adaptive_Cosine_Estimator.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"2\">' +
	'            <TocEntry Title=\"About the Adaptive Cosine Estimator\" Link=\"/Content/Material_ID/About_the_Adaptive_Cosine_Estimator.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"Run ACE\" Link=\"/Content/Material_ID/Run_ACE.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        </TocEntry>' +
	'        <TocEntry Title=\"Constrained Energy Minimization (CEM)\" Link=\"/Content/Material_ID/constrained_energy_minimization_(cem).htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Spectral Angle Mapper (SAM)\" Link=\"/Content/Material_ID/spectral_angle_mapper_(sam).htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Working With Signature Filters\" Link=\"/Content/Material_ID/Working_With_Signature_Filters.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Spectral Library Match\" Link=\"/Content/Material_ID/Spectral_Library_Match/Spectral_Library_Match.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"4\">' +
	'            <TocEntry Title=\"Spectral Library Match\" Link=\"/Content/Material_ID/Spectral_Library_Match/Spectral_Library_Match.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"Spectral Library Match Options\" Link=\"/Content/Material_ID/Spectral_Library_Match/SLM_Options.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"SLM Simple Interface\" Link=\"/Content/Material_ID/Spectral_Library_Match/SLM_Simple_Interface.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'            <TocEntry Title=\"SLM Advanced Interface\" Link=\"/Content/Material_ID/Spectral_Library_Match/SLM_Advanced_Interface.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        </TocEntry>' +
	'    </TocEntry>' +
	'    <TocEntry Title=\"Anomaly Detectors\" Link=\"/Content/Anomaly_Detectors/RX_Anomaly_Detector.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"2\">' +
	'        <TocEntry Title=\"RX Anomaly Detector\" Link=\"/Content/Anomaly_Detectors/RX_Anomaly_Detector.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Topological Anomaly Detector\" Link=\"/Content/Anomaly_Detectors/Topological_Anomaly_Detector.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'    </TocEntry>' +
	'    <TocEntry Title=\"Classification\" Link=\"/Content/Classification/K-Means.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"1\">' +
	'        <TocEntry Title=\"K-Means\" Link=\"/Content/Classification/K-Means.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'    </TocEntry>' +
	'    <TocEntry Title=\"Signature Window Plug-In\" Link=\"/Content/Signature_Window_Plug-In/Signature_Window_Plug_In.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"6\">' +
	'        <TocEntry Title=\"Signature Window Plug-In\" Link=\"/Content/Signature_Window_Plug-In/Signature_Window_Plug_In.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Pin/Unpin Signature Window\" Link=\"/Content/Signature_Window_Plug-In/Pin_Unpin_Signature_Window.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Display Pixel Signature\" Link=\"/Content/Signature_Window_Plug-In/Display_Pixel_Signature.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Display AOI Signatures and the AOI Average Signature\" Link=\"/Content/Signature_Window_Plug-In/Display AOI Signatures.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Display the AOI Average Signature\" Link=\"/Content/Signature_Window_Plug-In/Display_AOI_Average_Signature.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Signature Window Configuration Settings\" Link=\"/Content/Signature_Window_Plug-In/Signature_Window_Configuration_Settings.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'    </TocEntry>' +
	'    <TocEntry Title=\"Exporters\" Link=\"/Content/Exporters/signature_exporter.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"2\">' +
	'        <TocEntry Title=\"Signature Exporter\" Link=\"/Content/Exporters/signature_exporter.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'        <TocEntry Title=\"Spectral Signature Library Exporter\" Link=\"/Content/Exporters/spectral_signature_library_exporter.htm\" ComputedFirstTopic=\"false\" DescendantCount=\"0\" />' +
	'    </TocEntry>' +
	'</CatapultToc>'
);
